	

import gi
import numpy as np
import cv2
from openalpr import Alpr
import sys
import serial
import sqlite3
import subprocess
import os



gi.require_version("Gtk", "3.0")
from gi.repository import Gtk


class ButtonWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="ALPRS 0.2")
        self.set_border_width(10)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_default_size(250, 350)

        
        self.outter_box = Gtk.VBox(False,spacing=10)
        self.add(self.outter_box)
        
        hbox = Gtk.ButtonBox.new(Gtk.Orientation.HORIZONTAL)
        hbox.set_layout(Gtk.ButtonBoxStyle.CENTER) 
        self.outter_box.pack_start(hbox, False, True, 0)
        
        hbox.get_style_context().add_class("linked")

        button = Gtk.Button.new_with_label("Allowed")
        hbox.add(button)
        button.connect("clicked", self.on_click_me_clicked)
        #hbox.pack_start(button, True, True, 0)
        
        button = Gtk.Button.new_with_mnemonic("_Close")
        hbox.add(button)
        button.connect("clicked", self.on_close_clicked)
        #hbox.pack_start(button, True, True, 0)
        
        button = Gtk.Button.new_with_mnemonic("Start the Engine")
        hbox.add(button)
        button.connect("clicked", self.on_button_clicked)
        #hbox.pack_start(button, True, True, 0)
        
        
        hbox = Gtk.Box(Gtk.Orientation.HORIZONTAL)
        self.outter_box.pack_end(hbox, False, True, 0)
        self.entry = Gtk.Entry()
        self.entry.set_text("Hello World")
        self.status_log = Gtk.Label("Status : ")
        hbox.add(self.entry)
        #vbox.pack_start(self.entry, True, True, 0)


        
        

        
        #label_display.set_text("sdsd")
        
    def on_click_me_clicked(self, button):
		subprocess.Popen(["python", "allowed.py"])

    def on_button_clicked(self, button):


		if __name__ == "__main__":
			main()



    def on_open_clicked(self, button):
        print('"Open" button was clicked')

    def on_close_clicked(self, button):
        print("Closing application")
        Gtk.main_quit()


win = ButtonWindow()
win.connect("destroy", Gtk.main_quit)
win.show_all()
Gtk.main()
