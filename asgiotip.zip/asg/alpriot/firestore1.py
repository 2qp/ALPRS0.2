import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Use a service account
cred = credentials.Certificate('./avmsystem-9811f-firebase-adminsdk-t24ce-47db31506e.json')
firebase_admin.initialize_app(cred)

db = firestore.client()


# Then query for documents
plates_ref = db.collection(u'plates')

for doc in plates_ref.stream():
    print(u'{} => {}'.format(doc.id, doc.to_dict()))
