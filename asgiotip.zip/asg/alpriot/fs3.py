import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import numpy
import json, ast


# Use a service account
cred = credentials.Certificate('./avmsystem-9811f-firebase-adminsdk-t24ce-47db31506e.json')
firebase_admin.initialize_app(cred)

db = firestore.client()


# Then query for documents
plates_ref = db.collection(u'plates')


#log_ref = db.collection('logs').document(doc.id).set({ 'time' : (now), 'plate': 1234})

J = 'Guna'
K = (u'{}'.format(J))
user_id = plates_ref.where(u'name', u'==', K).stream()

for doc in user_id:
    tempinfo = (u'{}{}'.format(doc.id, doc.to_dict()))
    
print(tempinfo)
