import serial
import sys
import os


arduino =serial.Serial('/dev/ttyACM0', 9600)
command = str(85)
arduino.write(command)
reachedPos = str(arduino.readline())
