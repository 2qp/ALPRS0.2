import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import numpy
import json, ast


# Use a service account
cred = credentials.Certificate('./avmsystem-9811f-firebase-adminsdk-t24ce-47db31506e.json')
firebase_admin.initialize_app(cred)

db = firestore.client()


# Then query for documents
plates_ref = db.collection(u'plates')

arrayload = []

for doc in plates_ref.stream():
    payload = (u'{},'.format(doc.to_dict().get('plate')))
    arrayload.append(payload)
    
print(arrayload)
with open('output.txt', 'w') as output:
	output.write(str(arrayload))
	

now = firestore.SERVER_TIMESTAMP

K = 123

log_ref = db.collection('logs').document(doc.id).set({ 'time' : (now), 'plate': 1234})
#print(log_ref)

print(doc.id)

J = 'KL6036'
K = (u'{}'.format(J))
user_id = plates_ref.where(u'plate', u'==', K).stream()

for doc in user_id:
    tempinfo = (u'{}'.format(doc.id))
    
print(doc.id)
