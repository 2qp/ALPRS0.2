import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/rendering.dart';

FirebaseFirestore firestore = FirebaseFirestore.instance;

class aDmin extends StatefulWidget {
  @override
  _aDmin createState() => _aDmin();
}

class _aDmin extends State<aDmin> {
  @override
  Widget build(BuildContext context) {
    CollectionReference logs = FirebaseFirestore.instance.collection('logs');
    CollectionReference userName =
        FirebaseFirestore.instance.collection('plates');

    return new Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: new AppBar(
          title: new Text("Logs"),
          actions: <Widget>[
            new IconButton(icon: const Icon(Icons.refresh), onPressed: () {})
          ],
        ),
        //  FirebaseFirestore.instance.collection('plates').where('plate', isEqualTo: 'KL6036')
        body: StreamBuilder<QuerySnapshot>(

          stream: logs.snapshots(),

          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasError) {
              return Text('Something went wrong');
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text("Loading");
            }


            return new ListView(
              children: snapshot.data.docs.map((DocumentSnapshot document) {
                Timestamp t = document.data()['time'];
                DateTime d = t.toDate();
                String plateid = document.data()['plate'];

                return StreamBuilder(
                    stream: userName.snapshots(),
                    builder: (context, snapshot) {
                      //type TimeStamp is not a subtype of type string firebase flutter solution

                      return new Card(
                        child: new ListTile(
                          leading: Icon(Icons.time_to_leave_rounded),
                          title: new Text(document.data()['plate']),
                          subtitle: new Text(d.toString()),
                          //trailing: new Text(document.data()['name']),
                          dense: true,
                        ),
                      );
                    });
              }).toList(),
            );
          },
        ));
  }
}

